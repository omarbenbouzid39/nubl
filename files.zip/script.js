// ─── DOM Elements ───
const loginScreen = document.getElementById('login-screen');
const chatScreen = document.getElementById('chat-screen');
const usernameInput = document.getElementById('username-input');
const joinBtn = document.getElementById('join-btn');
const messagesArea = document.getElementById('messages');
const messageInput = document.getElementById('message-input');
const sendBtn = document.getElementById('send-btn');
const imageUpload = document.getElementById('image-upload');
const imagePreview = document.getElementById('image-preview');
const previewImg = document.getElementById('preview-img');
const removeImg = document.getElementById('remove-img');
const typingIndicator = document.getElementById('typing-indicator');
const typingName = document.getElementById('typing-name');
const usersList = document.getElementById('users-list');
const myAvatar = document.getElementById('my-avatar');
const myNameDisplay = document.getElementById('my-name-display');
const connectionBadge = document.getElementById('connection-badge');
const badgeText = connectionBadge.querySelector('.badge-text');
const onlineCount = document.getElementById('online-count');
const roomStatus = document.getElementById('room-status');
const imgModal = document.getElementById('img-modal');
const modalImg = document.getElementById('modal-img');
const modalClose = document.getElementById('modal-close');
const modalBackdrop = document.getElementById('modal-backdrop');

// ─── State ───
let socket = null;
let myUsername = '';
let mySocketId = '';
let pendingImageUrl = null;
let typingTimeout = null;
let isTyping = false;

// ─── Join Chat ───
function joinChat() {
  const username = usernameInput.value.trim();
  if (!username) {
    usernameInput.focus();
    usernameInput.style.borderColor = '#ef4444';
    setTimeout(() => (usernameInput.style.borderColor = ''), 1000);
    return;
  }

  myUsername = username;
  myAvatar.textContent = username.charAt(0).toUpperCase();
  myNameDisplay.textContent = username;

  // Animate out login screen
  loginScreen.style.animation = 'fadeOut 0.3s ease forwards';
  setTimeout(() => {
    loginScreen.classList.add('hidden');
    chatScreen.classList.remove('hidden');
    chatScreen.style.animation = 'fadeIn 0.3s ease';
    connectSocket();
  }, 280);
}

joinBtn.addEventListener('click', joinChat);
usernameInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') joinChat();
});

// ─── Socket.io Connection ───
function connectSocket() {
  socket = io();
  mySocketId = null;

  socket.on('connect', () => {
    mySocketId = socket.id;
    setConnectionStatus(true);
    socket.emit('join', myUsername);
  });

  socket.on('disconnect', () => {
    setConnectionStatus(false);
    roomStatus.textContent = 'غير متصل...';
  });

  socket.on('connect_error', () => {
    setConnectionStatus(false);
  });

  // Receive message history
  socket.on('history', (msgs) => {
    msgs.forEach((msg) => renderMessage(msg));
    scrollToBottom();
  });

  // New message
  socket.on('message', (msg) => {
    // Remove welcome message on first msg
    const welcome = messagesArea.querySelector('.welcome-msg');
    if (welcome) welcome.remove();

    renderMessage(msg);
    scrollToBottom();

    // Notification sound (subtle)
    if (msg.socketId !== mySocketId) playNotificationSound();
  });

  // User joined
  socket.on('user_joined', (data) => {
    if (data.username !== myUsername) {
      addSystemMessage(`${data.username} انضم إلى الدردشة 👋`);
    }
    updateUsersList(data.users);
    updateOnlineCount(data.count);
    roomStatus.textContent = `${data.count} متصل`;
  });

  // User left
  socket.on('user_left', (data) => {
    addSystemMessage(`${data.username} غادر الدردشة`);
    updateUsersList(data.users);
    updateOnlineCount(data.count);
    roomStatus.textContent = `${data.count} متصل`;
  });

  // Typing indicator
  socket.on('typing', (data) => {
    if (data.isTyping) {
      typingName.textContent = data.username;
      typingIndicator.classList.remove('hidden');
      scrollToBottom();
    } else {
      typingIndicator.classList.add('hidden');
    }
  });
}

// ─── Connection Status ───
function setConnectionStatus(online) {
  if (online) {
    connectionBadge.className = 'connection-badge online';
    badgeText.textContent = 'متصل';
  } else {
    connectionBadge.className = 'connection-badge offline';
    badgeText.textContent = 'غير متصل';
  }
}

// ─── Update Users List ───
function updateUsersList(users) {
  usersList.innerHTML = '';
  users.forEach((username) => {
    const item = document.createElement('div');
    item.className = 'user-item';
    item.innerHTML = `
      <div class="user-avatar">${username.charAt(0).toUpperCase()}</div>
      <div class="user-name">${escapeHtml(username)}</div>
    `;
    usersList.appendChild(item);
  });
}

function updateOnlineCount(count) {
  onlineCount.textContent = `${count} متصل الآن`;
}

// ─── Send Text Message ───
function sendMessage() {
  const text = messageInput.value.trim();
  const hasImage = pendingImageUrl !== null;

  if (!text && !hasImage) return;
  if (!socket || !socket.connected) return;

  if (hasImage) {
    socket.emit('image_message', {
      imageUrl: pendingImageUrl,
      caption: text
    });
    clearImagePreview();
  } else {
    socket.emit('message', { text });
  }

  messageInput.value = '';
  messageInput.style.height = 'auto';
  stopTyping();
}

sendBtn.addEventListener('click', sendMessage);

messageInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

// Auto-resize textarea
messageInput.addEventListener('input', () => {
  messageInput.style.height = 'auto';
  messageInput.style.height = Math.min(messageInput.scrollHeight, 120) + 'px';
  handleTyping();
});

// ─── Typing Indicator ───
function handleTyping() {
  if (!socket || !socket.connected) return;

  if (!isTyping) {
    isTyping = true;
    socket.emit('typing', true);
  }

  clearTimeout(typingTimeout);
  typingTimeout = setTimeout(stopTyping, 1500);
}

function stopTyping() {
  if (isTyping && socket) {
    isTyping = false;
    socket.emit('typing', false);
  }
  clearTimeout(typingTimeout);
}

// ─── Image Upload ───
imageUpload.addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const formData = new FormData();
  formData.append('image', file);

  try {
    const res = await fetch('/upload', { method: 'POST', body: formData });
    const data = await res.json();

    if (data.url) {
      pendingImageUrl = data.url;
      previewImg.src = data.url;
      imagePreview.classList.remove('hidden');
      messageInput.placeholder = 'أضف تعليقاً للصورة (اختياري)...';
      messageInput.focus();
    }
  } catch (err) {
    console.error('Upload error:', err);
    alert('فشل رفع الصورة. تأكد من السيرفر.');
  }

  imageUpload.value = '';
});

removeImg.addEventListener('click', clearImagePreview);

function clearImagePreview() {
  pendingImageUrl = null;
  previewImg.src = '';
  imagePreview.classList.add('hidden');
  messageInput.placeholder = 'اكتب رسالتك...';
}

// ─── Render Message ───
function renderMessage(msg) {
  const isMe = msg.socketId === mySocketId || msg.username === myUsername;
  const wrapper = document.createElement('div');
  wrapper.className = `message-wrapper ${isMe ? 'me' : 'them'}`;

  const time = formatTime(msg.timestamp);

  let bubbleContent = '';

  if (msg.type === 'image') {
    bubbleContent = `
      <div class="bubble image-bubble">
        <img
          class="chat-image"
          src="${escapeHtml(msg.imageUrl)}"
          alt="صورة"
          loading="lazy"
          onclick="openModal('${escapeHtml(msg.imageUrl)}')"
        />
        ${msg.caption ? `<div class="img-caption">${escapeHtml(msg.caption)}</div>` : ''}
      </div>
    `;
  } else {
    bubbleContent = `<div class="bubble">${escapeHtml(msg.text).replace(/\n/g, '<br>')}</div>`;
  }

  wrapper.innerHTML = `
    <div class="msg-meta">
      ${!isMe ? `<span class="msg-username">${escapeHtml(msg.username)}</span>` : ''}
      <span class="msg-time">${time}</span>
    </div>
    ${bubbleContent}
  `;

  messagesArea.appendChild(wrapper);
}

// ─── System Message ───
function addSystemMessage(text) {
  const el = document.createElement('div');
  el.className = 'system-msg';
  el.textContent = text;
  messagesArea.appendChild(el);
  scrollToBottom();
}

// ─── Scroll to Bottom ───
function scrollToBottom() {
  requestAnimationFrame(() => {
    messagesArea.scrollTop = messagesArea.scrollHeight;
  });
}

// ─── Image Modal ───
function openModal(url) {
  modalImg.src = url;
  imgModal.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  imgModal.classList.add('hidden');
  document.body.style.overflow = '';
  modalImg.src = '';
}

modalClose.addEventListener('click', closeModal);
modalBackdrop.addEventListener('click', closeModal);

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeModal();
});

// ─── Notification Sound ───
function playNotificationSound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = 880;
    osc.type = 'sine';
    gain.gain.setValueAtTime(0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.3);
  } catch (_) {}
}

// ─── Utils ───
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function formatTime(iso) {
  try {
    const d = new Date(iso);
    return d.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', hour12: false });
  } catch (_) {
    return '';
  }
}

// CSS animation for login out
const style = document.createElement('style');
style.textContent = `@keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }`;
document.head.appendChild(style);
